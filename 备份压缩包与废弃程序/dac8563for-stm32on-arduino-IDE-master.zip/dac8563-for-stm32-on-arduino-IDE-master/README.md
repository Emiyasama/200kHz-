# DAC8563
A simple Arduino library for 16bit SPI controlled DAC
and all codes is modified from https://github.com/k164v/DAC8562
The original code cannot be compiled to stm32, and there were some minor bugs for dac8563.
Thanks for k164v
